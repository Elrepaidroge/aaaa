package com.example.sastreriapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Reportes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.reportes)
    }
}