package com.example.sastreriapp

import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PedidosActividad : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PedidoAdapter
    private lateinit var pedidosList: MutableList<Pedido>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pedidos_actividad)

        recyclerView = findViewById(R.id.rvrecyclerView) // Ajusta el ID según tu layout
        recyclerView.layoutManager = LinearLayoutManager(this)
        pedidosList = mutableListOf()
        adapter = PedidoAdapter(pedidosList)
        recyclerView.adapter = adapter

        // Cargar los pedidos al iniciar la actividad
        cargarPedidos()

        // Configurar el botón flotante para agregar pedidos
        val botonAgregar: FloatingActionButton = findViewById(R.id.agregar) // Ajusta el ID
        botonAgregar.setOnClickListener {
            mostrarDialogoAgregarPedido()
        }
    }

    private fun cargarPedidos() {
        RetrofitClient.instance.obtenerPedidos().enqueue(object : Callback<List<Pedido>> {
            override fun onResponse(call: Call<List<Pedido>>, response: Response<List<Pedido>>) {
                if (response.isSuccessful) {
                    pedidosList.clear()
                    response.body()?.let { pedidosList.addAll(it) }
                    adapter.notifyDataSetChanged()
                } else {
                    Toast.makeText(this@PedidosActividad, "Error al cargar pedidos", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<Pedido>>, t: Throwable) {
                Toast.makeText(this@PedidosActividad, "Error al conectar con el servidor", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun mostrarDialogoAgregarPedido() {
        val dialogView = layoutInflater.inflate(R.layout.registrarpedido, null)
        val nombreInput = dialogView.findViewById<EditText>(R.id.et_nombre)
        val fechaInput = dialogView.findViewById<EditText>(R.id.et_fecha_entrega)
        val cantidadInput = dialogView.findViewById<EditText>(R.id.et_cantidad)
        val tipoPrendaInput = dialogView.findViewById<EditText>(R.id.et_tipo_prenda)
        val precioInput = dialogView.findViewById<EditText>(R.id.et_precio_total)
        val anticipoInput = dialogView.findViewById<EditText>(R.id.et_anticipo)
        val liquidacionInput = dialogView.findViewById<EditText>(R.id.et_liquidacion)

        AlertDialog.Builder(this)
            .setTitle("Agregar Pedido")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val nombre = nombreInput.text.toString()
                val fecha = fechaInput.text.toString()
                val cantidad = cantidadInput.text.toString().toInt()
                val tipoPrenda = tipoPrendaInput.text.toString()
                val precio = precioInput.text.toString().toDouble()
                val anticipo = anticipoInput.text.toString().toDouble()
                val liquidacion = liquidacionInput.text.toString().toDouble()

                insertarPedido(nombre, fecha, tipoPrenda, cantidad, precio, anticipo, liquidacion)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun insertarPedido(
        nombre: String, fecha: String, tipoPrenda: String,
        cantidad: Int, precio: Double, anticipo: Double, liquidacion: Double
    ) {
        RetrofitClient.instance.insertarPedido(nombre, fecha, tipoPrenda, cantidad, precio, anticipo, liquidacion)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@PedidosActividad, "Pedido agregado", Toast.LENGTH_SHORT).show()
                        cargarPedidos()
                    } else {
                        Toast.makeText(this@PedidosActividad, "Error al agregar pedido", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@PedidosActividad, "Error al conectar con el servidor", Toast.LENGTH_SHORT).show()
                }
            })
    }
}
