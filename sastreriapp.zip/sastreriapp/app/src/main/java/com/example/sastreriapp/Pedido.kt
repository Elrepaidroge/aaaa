package com.example.sastreriapp

data class Pedido(
    val id: Int,
    val nombre_cliente: String,
    val fecha_entrega: String,
    val tipo_prenda: String,
    val cantidad_prendas: Int,
    val precio_total: Double,
    val anticipo: Double,
    val liquidacion: Double
)
