package com.example.sastreriapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PedidoAdapter(private val pedidos: List<Pedido>) : RecyclerView.Adapter<PedidoAdapter.PedidoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PedidoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pedido, parent, false)
        return PedidoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PedidoViewHolder, position: Int) {
        val pedido = pedidos[position]
        holder.bind(pedido)
    }

    override fun getItemCount() = pedidos.size

    class PedidoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nombreCliente: TextView = itemView.findViewById(R.id.et_nombre)
        private val fechaEntrega: TextView = itemView.findViewById(R.id.et_fecha_entrega)
        private val tipoPrenda: TextView = itemView.findViewById(R.id.et_tipo_prenda)
        private val cantidadPrendas: TextView = itemView.findViewById(R.id.et_cantidad)
        private val precioTotal: TextView = itemView.findViewById(R.id.et_precio_total)
        private val anticipo: TextView = itemView.findViewById(R.id.et_anticipo)
        private val liquidacion: TextView = itemView.findViewById(R.id.et_liquidacion)

        fun bind(pedido: Pedido) {
            nombreCliente.text = pedido.nombre_cliente
            fechaEntrega.text = pedido.fecha_entrega
            tipoPrenda.text = "Tipo: ${pedido.tipo_prenda}"
            cantidadPrendas.text = "Cantidad: ${pedido.cantidad_prendas}"
            precioTotal.text = "Precio: $${pedido.precio_total}"
            anticipo.text = "Anticipo: $${pedido.anticipo}"
            liquidacion.text = "Liquidación: $${pedido.liquidacion}"
        }
    }
}
