package com.example.sastreriapp

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("obtener_pedidos.php")
    fun obtenerPedidos(): Call<List<Pedido>>

    @FormUrlEncoded
    @POST("insertar_pedido.php")
    fun insertarPedido(
        @Field("nombre_cliente") nombreCliente: String,
        @Field("fecha_entrega") fechaEntrega: String,
        @Field("tipo_prenda") tipoPrenda: String,
        @Field("cantidad_prendas") cantidadPrendas: Int,
        @Field("precio_total") precioTotal: Double,
        @Field("anticipo") anticipo: Double,
        @Field("liquidacion") liquidacion: Double
    ): Call<ResponseBody>
}
